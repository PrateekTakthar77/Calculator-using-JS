let num1 = 20
let num2 = 10

document.getElementById("num1-el").textContent = num1
document.getElementById("num2-el").textContent = num2

let sumEl = document.getElementById("sum-el")
function add(){
    let result = num1 + num2
    sumEl.textContent = "Sum: " + result
}

function subtracted(){
    let result = num1 - num2
    sumEl.textContent = "Sum: " + result
}

function divide() {
    let result = num1 / num2
    sumEl.textContent = "sum: " + result
}
function multiply() {
    let result = num1 * num2
    sumEl.textContent = "sum: " + result
}